package gui;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JPanel;


import data.board.Board;
import data.board.Card;
import data.board.GameMonitor;
import data.board.Move;
import data.player.HumanPlayer;
import data.player.Player;

@SuppressWarnings("serial")
public class ButtonPanel extends JPanel {

	/** Control Commands and Labels */
	private static final String DRAW_COMMAND = "Draw";
	private static final String DISCARD_COMMAND = "Discard";
	private static final String LAST_CARD_COMMAND = "Last Card";
	private static final String DEAL_COMMAND = "Deal";

	/** Name of the property the indicates number of cards */
	private static final String NUMBER_PROPERTY = "Number";
	
	/** List of Card Suits to be displayed */
	private static final Card.Suit[] SUIT_LIST = new Card.Suit[] {
		Card.Suit.Club,
		Card.Suit.Diamond,
		Card.Suit.Heart,
		Card.Suit.Spade,
	};
	
	/** Stores reference to Board */
	private Board _board;
	
	/** Stores reference to DrawAction */
	private DrawAction _drawAction;
	
	/** Stores reference to DiscardAction */
	private DiscardAction _discardAction;
	
	/** Stores reference to DealAction */
	private DealAction _dealAction;
	
	/** Stores reference to Draw button */
	private JButton _drawButton;
	
	/** Stores reference to LastCard CheckBox */
	private JCheckBox _lastCardCheckBox;
	
	/** Stores reference to JComboBox that displays choice of card suits */
	private JComboBox _suitList;
	
	/**
	 * Returns the Card Suit selected by user through _suitList JComboBox.
	 * 
	 * @return selected Card Suit, or Card.Suit.NONE if none are selected.
	 */
	private Card.Suit getSelectedSuit() {
		int idx = _suitList.getSelectedIndex();
		if (idx == 0) {
			return Card.Suit.NONE;
		} else {
			return SUIT_LIST[idx-1];
		}
	}
	
	/**
	 * Starts a new round of the game.
	 */
	private void newRound() {

		_board.reset(false);
		_board.initialize();

	}

	/**
	 * Checks if LastCard CheckBox is checked by user.
	 * 
	 * @return true if LastCard CheckBox is checked by user.
	 */
	private boolean isLastCardSelected() {
		return _lastCardCheckBox.isSelected();
	}
	
	/**
	 * Creates an instance of ButtonPanel.
	 * 
	 * @param board associated Board.
	 */
	public ButtonPanel (Board board) {
		_board = board;
		
		// create actions
		_drawAction = new DrawAction(DRAW_COMMAND);
		_discardAction = new DiscardAction(DISCARD_COMMAND);
		_dealAction = new DealAction(DEAL_COMMAND);
		
		// create buttons and other controls 
		_drawButton = new JButton(_drawAction);
		JButton discardButton = new JButton(_discardAction);
		JButton dealButton = new JButton(_dealAction);
		_lastCardCheckBox = new JCheckBox(LAST_CARD_COMMAND);
		_lastCardCheckBox.setBackground(LastCardUI.BACKGROUND_COLOR);
		String[] suits = new String[5];
		suits[0] = "";
		for (int i = 0; i < SUIT_LIST.length; i++) {
			suits[i+1] = SUIT_LIST[i].toString();
		}
		_suitList = new JComboBox(suits);
		_suitList.setEditable(false);
		
		// add controls to the panel
		add(_drawButton);
		add(discardButton);
		add(_lastCardCheckBox);
		add(_suitList);
		add(dealButton);

		// set background to match App background
		setBackground(LastCardUI.BACKGROUND_COLOR);
	}
	
	/**
	 * Updates controls on the Panel to reflect game progress.
	 */
	public void refresh() {
		
		// reset LastCard and Suit user options
		_suitList.setSelectedIndex(0);
		_lastCardCheckBox.setSelected(false);
		
		// change Draw button's label string based on number
		// of cards user must draw
		GameMonitor monitor = _board.getGameMonitor();
		GameMonitor.State state = monitor.getCurrentState();
		if (state == GameMonitor.State.DrawTwo) {
			_drawAction.putValue(NUMBER_PROPERTY, 2);
			_drawButton.setText(DRAW_COMMAND + " 2");
		} else if (state == GameMonitor.State.Melee) {
			int meleeVal = _board.getDiscardPile().lastDiscarded().getValue();
			_drawAction.putValue(NUMBER_PROPERTY, meleeVal);
			_drawButton.setText(DRAW_COMMAND + " " + meleeVal);
		} else {
			_drawAction.putValue(NUMBER_PROPERTY, 1);
			_drawButton.setText(DRAW_COMMAND);
		}
		
		// enable or disable controls based on game status 
		if (monitor.isRoundOver() || monitor.isGameOver()) {
			_drawAction.setEnabled(false);
			_discardAction.setEnabled(false);
			_lastCardCheckBox.setEnabled(false);
			_suitList.setEnabled(false);
			if (monitor.isGameOver()) {
				_dealAction.setEnabled(false);
			} else {
				_dealAction.setEnabled(true);
			}
		} else {
			
			// if stock is empty disable draw button
			if( _board.getStock().isEmpty()) {
				_drawAction.setEnabled(false);
			} else {
				_drawAction.setEnabled(true);
			}

			_discardAction.setEnabled(true);
			_lastCardCheckBox.setEnabled(true);
			_suitList.setEnabled(true);
			_dealAction.setEnabled(false);
		}
	}
	
	/**
	 * Handles Draw Button events. 
	 */
	class DrawAction extends AbstractAction {

		/**
		 * Creates an instance of DrawAction.
		 * 
		 * @param name Display name.
		 */
		public DrawAction(String name) {
			super(name);
			
			// draw 1 card by default
			putValue(NUMBER_PROPERTY, 1);
		}
		
		public void actionPerformed(ActionEvent evt) {
			
			// obtain number of cards to draw
			int num = (Integer) getValue(NUMBER_PROPERTY);
			HumanPlayer player = (HumanPlayer) _board.getPlayer(Player.HUMAN_PLAYER_INDEX);
			player.putNextMove(new Move(Move.Type.Draw, num));
		}
		
	}
	
	/**
	 * Handles Discard Button events.
	 */
	class DiscardAction extends AbstractAction {

		public DiscardAction(String name) {
			super(name);
		}
		
		public void actionPerformed(ActionEvent evt) {
			
			HumanPlayer player = (HumanPlayer)_board.getPlayer(Player.HUMAN_PLAYER_INDEX);
			Move move = new Move(Move.Type.Discard, 
					player.getHand().getSelectedCardIndex(),
					getSelectedSuit());
			if (isLastCardSelected()) {
				move.setLastCard(true);
			} 
			player.putNextMove(move);
		}
		
	}

	/**
	 * Handles Deal Button events.
	 */
	class DealAction extends AbstractAction {

		public DealAction(String name) {
			super(name);
		}
		
		public void actionPerformed(ActionEvent evt) {
			newRound();
		}
		
	}
}
