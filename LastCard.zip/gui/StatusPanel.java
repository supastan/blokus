package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.text.StyledDocument;

@SuppressWarnings("serial")
public class StatusPanel extends JPanel {

	/** Preferred width of status panel */
	private static final int PREFERRED_WIDTH = 600;
	
	/** Preferred height of status panel */
	private static final int PREFERRED_HEIGHT = 120;
	
	/** Stores reference to JTextPane */
	private JTextPane _txtPane;
	
	/**
	 * Creates a StatusPanel tied to given Document.
	 * 
	 * @param doc StyleDocument to be associated with the JTextPane.
	 */
	public StatusPanel(StyledDocument doc) {
	
		_txtPane = new JTextPane(doc);
		_txtPane.setEditable(false);
		JScrollPane scrlPane = new JScrollPane(_txtPane);
		scrlPane.setPreferredSize(new Dimension(PREFERRED_WIDTH, PREFERRED_HEIGHT));
		
		setLayout(new BorderLayout());
		add(scrlPane, BorderLayout.CENTER);
	}
	
	/**
	 * ScrollDown to bottom of the document.
	 */
	public void refresh() {
		_txtPane.setCaretPosition(_txtPane.getDocument().getLength());
	}
}
