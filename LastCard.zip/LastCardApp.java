

import gui.LastCardUI;

import java.util.Observable;
import java.util.Observer;

import data.board.Board;

public class LastCardApp implements Observer {

	/** Stores reference to LastCardUI */
	private LastCardUI _ui;
	
	/** Stores reference to Board */
	private Board _board;
	
	/** 
	 * Creates a new LastCard game and sets up the board. 
	 */
	public LastCardApp() {
		_board = new Board();
		_board.getGameMonitor().addObserver(this);
		_ui = new LastCardUI(_board);
		_ui.display();
	}

	/**
	 * Starts game by showing UI.
	 */
	public void start() {
		_board.reset(true);
		_board.initialize();
		_ui.refresh();
	}

	/**
	 * Callback interface for GameMonitor to notify change in the game.
	 */
	public void update(Observable obj, Object status) {
		_ui.refresh();
	}
	
	/**
	 * Program execution entry point.
	 * 
	 * @param args command line arguments (unused)
	 */
	public static void main(String[] args) {
		LastCardApp app = new LastCardApp();
		app.start();
	}
	
	
}
