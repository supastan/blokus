package data.board;

import javax.swing.ImageIcon;

public class Deck extends CardCollection {

	/**
	 * Populates deck with standard 52 cards.
	 */
	private void populateDeck() {
		// clubs
		add(new Card(Card.Suit.Club, Card.Kind.Ace, new ImageIcon("1c.jpg")));
		add(new Card(Card.Suit.Club, Card.Kind.Two, new ImageIcon("2c.jpg")));
		add(new Card(Card.Suit.Club, Card.Kind.Three, new ImageIcon("3c.jpg")));
		add(new Card(Card.Suit.Club, Card.Kind.Four, new ImageIcon("4c.jpg")));
		add(new Card(Card.Suit.Club, Card.Kind.Five, new ImageIcon("5c.jpg")));
		add(new Card(Card.Suit.Club, Card.Kind.Six, new ImageIcon("6c.jpg")));
		add(new Card(Card.Suit.Club, Card.Kind.Seven, new ImageIcon("7c.jpg")));
		add(new Card(Card.Suit.Club, Card.Kind.Eight, new ImageIcon("8c.jpg")));
		add(new Card(Card.Suit.Club, Card.Kind.Nine, new ImageIcon("9c.jpg")));
		add(new Card(Card.Suit.Club, Card.Kind.Ten, new ImageIcon("0c.jpg")));
		add(new Card(Card.Suit.Club, Card.Kind.Jack, new ImageIcon("jc.jpg")));
		add(new Card(Card.Suit.Club, Card.Kind.Queen, new ImageIcon("qc.jpg")));
		add(new Card(Card.Suit.Club, Card.Kind.King, new ImageIcon("kc.jpg")));
		// spades
		add(new Card(Card.Suit.Spade, Card.Kind.Ace, new ImageIcon("1s.jpg")));
		add(new Card(Card.Suit.Spade, Card.Kind.Two, new ImageIcon("2s.jpg")));
		add(new Card(Card.Suit.Spade, Card.Kind.Three, new ImageIcon("3s.jpg")));
		add(new Card(Card.Suit.Spade, Card.Kind.Four, new ImageIcon("4s.jpg")));
		add(new Card(Card.Suit.Spade, Card.Kind.Five, new ImageIcon("5s.jpg")));
		add(new Card(Card.Suit.Spade, Card.Kind.Six, new ImageIcon("6s.jpg")));
		add(new Card(Card.Suit.Spade, Card.Kind.Seven, new ImageIcon("7s.jpg")));
		add(new Card(Card.Suit.Spade, Card.Kind.Eight, new ImageIcon("8s.jpg")));
		add(new Card(Card.Suit.Spade, Card.Kind.Nine, new ImageIcon("9s.jpg")));
		add(new Card(Card.Suit.Spade, Card.Kind.Ten, new ImageIcon("0s.jpg")));
		add(new Card(Card.Suit.Spade, Card.Kind.Jack, new ImageIcon("js.jpg")));
		add(new Card(Card.Suit.Spade, Card.Kind.Queen, new ImageIcon("qs.jpg")));
		add(new Card(Card.Suit.Spade, Card.Kind.King, new ImageIcon("ks.jpg")));
		// diamonds
		add(new Card(Card.Suit.Diamond, Card.Kind.Ace, new ImageIcon("1d.jpg")));
		add(new Card(Card.Suit.Diamond, Card.Kind.Two, new ImageIcon("2d.jpg")));
		add(new Card(Card.Suit.Diamond, Card.Kind.Three, new ImageIcon("3d.jpg")));
		add(new Card(Card.Suit.Diamond, Card.Kind.Four, new ImageIcon("4d.jpg")));
		add(new Card(Card.Suit.Diamond, Card.Kind.Five, new ImageIcon("5d.jpg")));
		add(new Card(Card.Suit.Diamond, Card.Kind.Six, new ImageIcon("6d.jpg")));
		add(new Card(Card.Suit.Diamond, Card.Kind.Seven, new ImageIcon("7d.jpg")));
		add(new Card(Card.Suit.Diamond, Card.Kind.Eight, new ImageIcon("8d.jpg")));
		add(new Card(Card.Suit.Diamond, Card.Kind.Nine, new ImageIcon("9d.jpg")));
		add(new Card(Card.Suit.Diamond, Card.Kind.Ten, new ImageIcon("0d.jpg")));
		add(new Card(Card.Suit.Diamond, Card.Kind.Jack, new ImageIcon("jd.jpg")));
		add(new Card(Card.Suit.Diamond, Card.Kind.Queen, new ImageIcon("qd.jpg")));
		add(new Card(Card.Suit.Diamond, Card.Kind.King, new ImageIcon("kd.jpg")));
		// hearts
		add(new Card(Card.Suit.Heart, Card.Kind.Ace, new ImageIcon("1h.jpg")));
		add(new Card(Card.Suit.Heart, Card.Kind.Two, new ImageIcon("2h.jpg")));
		add(new Card(Card.Suit.Heart, Card.Kind.Three, new ImageIcon("3h.jpg")));
		add(new Card(Card.Suit.Heart, Card.Kind.Four, new ImageIcon("4h.jpg")));
		add(new Card(Card.Suit.Heart, Card.Kind.Five, new ImageIcon("5h.jpg")));
		add(new Card(Card.Suit.Heart, Card.Kind.Six, new ImageIcon("6h.jpg")));
		add(new Card(Card.Suit.Heart, Card.Kind.Seven, new ImageIcon("7h.jpg")));
		add(new Card(Card.Suit.Heart, Card.Kind.Eight, new ImageIcon("8h.jpg")));
		add(new Card(Card.Suit.Heart, Card.Kind.Nine, new ImageIcon("9h.jpg")));
		add(new Card(Card.Suit.Heart, Card.Kind.Ten, new ImageIcon("0h.jpg")));
		add(new Card(Card.Suit.Heart, Card.Kind.Jack, new ImageIcon("jh.jpg")));
		add(new Card(Card.Suit.Heart, Card.Kind.Queen, new ImageIcon("qh.jpg")));
		add(new Card(Card.Suit.Heart, Card.Kind.King, new ImageIcon("kh.jpg")));
	}
	
	/**
	 * Creates an unshuffled standard deck.
	 */
	public Deck() {
		// populate deck with standard 52 cards
		populateDeck();
	}
}
