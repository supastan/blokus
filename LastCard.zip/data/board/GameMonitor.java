package data.board;

import java.util.Iterator;
import java.util.Observable;

import data.player.Hand;
import data.player.Player;

public class GameMonitor extends Observable implements Runnable {

	/** Game states */
	public enum State {
		Normal,
		DrawTwo,
		Stacking,
		Melee,
		SuitChanged,
		LastDrawPenalty,
	}

	/** Reference to board */
	private Board _board;
	
	/** Current game state */
	private State _curState;

	/** Next suit */
	private Card.Suit _nextSuit;
	
	/** Melee suit */
	private Card.Suit _meleeSuit;
	
	/** Kind needed to escalate Melee */
	private Card.Kind _meleeKind;
	
	/** Stop requested */
	private boolean _stopRequested;

	/**
	 * Processes player's move.
	 * 
	 * @param move player's move
	 * @return true if the opponent must take the next turn.
	 */
	private boolean processPlayerMove(Move move) {

		boolean changeTurn = false;
		switch (move.getType()) {
		case Draw:
			changeTurn = draw(move);
			break;
			
		case Discard:
			changeTurn = discard(move);
			break;
			
		case Quit:
			stop();
			changeTurn = true;
			break;
		}
		
		return changeTurn;
	}
	
	/**
	 * Attempts to draw indicated number of cards from the Stock.
	 * 
	 * @param move current Move.
	 * @return true if the opponent takes the next turn.
	 */
	private boolean draw(Move move) {
		
		// get necessary refences
		Player player = _board.getPlayer(_board.getCurrentPlayerIndex());
		Hand hand = player.getHand();
		Stock stock = _board.getStock();
		int num = move.getNumber();

		// see if stacking is in effect
		if (_curState == State.Stacking) {
			
			_board.appendMessage(Board.MessageType.Error,
					"> Stacking is in effect.");
			_board.appendMessage(Board.MessageType.Error,
					player.getName() + " must discard a card.");
			return false;

		}
		
		// attempt to draw number of cards requested
		int actual = 0;
		boolean done = false;
		for (int i = 0; !done && i < num; i++) {
			if (stock.isEmpty() && !restock()) {
				done = true;
			}
			if (!stock.isEmpty()) {
				hand.add(stock.draw());
				actual++;
			}
		}
		_board.appendMessage(Board.MessageType.Normal,
				"> " + player.getName() + " drew " + actual + " cards.");

		// draw requiring states are reset to normal
		if (_curState == State.DrawTwo ||
			_curState == State.Melee || 
			_curState == State.LastDrawPenalty) {
			_curState = State.Normal;
		}
		
		return true;
	}
	
	/**
	 * Attempts to discard a card selected from the player's hand.
	 * 
	 * @param move current Move.
	 * @return true if current Move results in change of turn.
	 */
	private boolean discard(Move move) {
		
		// get necesary references
		int idx = move.getNumber();
		boolean lastCard = move.isLastCard();
		Player player = _board.getPlayer(_board.getCurrentPlayerIndex());
		Hand hand = player.getHand();
		Card card = hand.getCard(idx);
		Card lastDiscarded = _board.getDiscardPile().lastDiscarded();

		if (_curState == State.DrawTwo) {
			
			_board.appendMessage(Board.MessageType.Error,
					"> " + player.getName() + " must draw 2 cards.");
			return false;
			
		} else if (_curState == State.LastDrawPenalty) {
			
			_board.appendMessage(Board.MessageType.Error,
					"> " + player.getName() + " must draw a card as penalty.");
			return false;
			
		} else if (_curState == State.Melee &&
				  (_meleeKind != card.getKind() || _meleeSuit != card.getSuit()) ) {
			
			_board.appendMessage(Board.MessageType.Error,
					"> Melee in progress.");
			StringBuilder sb = new StringBuilder();
			sb.append(player.getName());
			sb.append(" must draw " + lastDiscarded.getValue() + " cards or ");
			sb.append("discard " + _meleeKind + " of " + _meleeSuit + ".");
			_board.appendMessage(Board.MessageType.Error, sb.toString());
			return false;
			
		} else if (card.getKind() == Card.Kind.Eight &&
				   move.getSuit() == Card.Suit.NONE &&
				   hand.size() != 1) {
			
			_board.appendMessage(Board.MessageType.Error,
					"> Next suit not specified.");
			_board.appendMessage(Board.MessageType.Error,
					player.getName() + " must specify next Suit when discarding 8.");
			return false;
		}
		
		// check if last card is declared at proper time
		if (lastCard) {
			if (hand.size() != 2) {
				_board.appendMessage(Board.MessageType.Error,
					"> Last card can be declared only when discarding next to last card.");
				return false;
			} else {
				_board.appendMessage(Board.MessageType.LastCard,
					player.getName() + " declared last card.");
			}
		} else {
			if (hand.size() == 2) {
				_board.appendMessage(Board.MessageType.Error,
					"> Last card was NOT declared.");
				_board.appendMessage(Board.MessageType.Error,
						player.getName() + " must draw a card as penalty.");
				
				_curState = State.LastDrawPenalty;
				return false;
			}
		}


		// process for any special effects 
		boolean success = processForSpecialEffect(move); 
		if (success) {
		
			// remove selected card from the hand and put it in the
			// discard pile
			hand.removeCard(idx);
			_board.getDiscardPile().add(card);
			
			// reset selection
			hand.setSelectedCardIndex(0);

			// if we're stacking then don't change turn
			if (_curState == State.Stacking) {
				success = false;
			}
		} 
	
		return success;
	}
	
	/**
	 * Process current move for special effect cards.
	 * 
	 * @param move current Move.
	 * @return true if current Move results in change of turn.
	 */
	private boolean processForSpecialEffect(Move move) {
		
		// get necessary references
		Player player = _board.getPlayer(_board.getCurrentPlayerIndex());
		Hand hand = player.getHand();
		Card card = player.getHand().getCard(move.getNumber());
		Card lastDiscarded = _board.getDiscardPile().lastDiscarded();
		
		boolean changeTurn = true;
		
		if (lastDiscarded != null &&
			_curState == State.Melee && 
			card.getKind() == _meleeKind &&
			card.getSuit() == _meleeSuit) {
			
			// melee escalated
			_meleeKind = card.getNextKind();
			_meleeSuit = card.getSuit();
			
			_board.appendMessage(Board.MessageType.Normal,
					"> " + player.getName() + " discarded " + card + ".");
			_board.appendMessage(Board.MessageType.SpecialCard,
					"Melee escalated.");

		} else if (card.getKind() == Card.Kind.Eight) {
			
			// change suit
			_curState = State.SuitChanged;
			_nextSuit = move.getSuit();
			if (lastDiscarded == null) {
				_board.appendMessage(Board.MessageType.Normal,
					"> Initial card is " + card + ".");
			} else {
				_board.appendMessage(Board.MessageType.Normal,
					"> " + player.getName() + " discarded " + card + ".");
			}
			if (hand.size() != 1) {
				// notify change of suit unless discarding last card
				_board.appendMessage(Board.MessageType.SpecialCard,
					"Suit changed to " + _nextSuit + ".");
			}

		} else if (lastDiscarded != null &&
				   _curState == State.SuitChanged &&
				  (card.getKind() != lastDiscarded.getKind() &&
				   card.getSuit() != _nextSuit)) {
			
			_board.appendMessage(Board.MessageType.Error,
					"> Card must match Kind or the new Suit: " + _nextSuit + ".");
			changeTurn = false;
			
		} else if (lastDiscarded != null &&
				   _curState != State.SuitChanged &&
				   _curState != State.Stacking &&
				   card.getKind() != lastDiscarded.getKind() &&
				   card.getSuit() != lastDiscarded.getSuit()) {
				changeTurn = false;
				_board.appendMessage(Board.MessageType.Error,
					"> Card must match Kind or Suit.");
		} else {
			
			if (lastDiscarded == null) {
				_board.appendMessage(Board.MessageType.Normal,
					"> Initial card is " + card + ".");
			} else {
				_board.appendMessage(Board.MessageType.Normal,
					"> " + player.getName() + " discarded " + card + ".");
			}
			
			if (card.getKind() == Card.Kind.Two) {
				
				_curState = State.DrawTwo;
				_board.appendMessage(Board.MessageType.SpecialCard,
					"DrawTwo card discarded. Next player must draw two cards.");
			
			} else if (card.getKind() == Card.Kind.Three) {
				
				_curState = State.Stacking;
				if (hand.size() != 1) {
					_board.appendMessage(Board.MessageType.SpecialCard,
						"Stacking card discarded. Current player must discard one more card.");
				}
				
			} else if (card.getKind() == Card.Kind.Four) {
				
				_curState = State.Melee;
				_meleeKind = Card.Kind.Five;
				_meleeSuit = card.getSuit();
				_board.appendMessage(Board.MessageType.SpecialCard,
					"Melee started. Next player must draw 4 cards or escalate melee.");
		
			} else {
				_curState = State.Normal;
			}
		}
		
		return changeTurn;
	}
	
	/**
	 * Restock the stock pile with cards from the discarded pile.
	 * 
	 * @return true if restocking was successful, false if there were no more
	 * cards in the discarded pile.
	 */
	private boolean restock() {
		boolean result = false;
		CardCollection cards = _board.getDiscardPile().removeAllButOne();
		if (!cards.isEmpty()) {
			Stock stock = _board.getStock();
			while (!cards.isEmpty()) {
				stock.add(cards.removeRandom());
			}
			_board.appendMessage(Board.MessageType.Normal,
				"Cards from discarded pile were restocked.");
			result = true;
		} 
		return result;
	}
	
	/**
	 * Calculates and updates each player's scores.
	 */
	private void updateScores() {
		
		for (int i = 0; i < Player.NUMBER_PLAYERS; i++) {
			int score = 0;
			Player player = _board.getPlayer(i);
			Hand hand = player.getHand();
			Iterator<Card> iter = hand.iterator();
			while (iter.hasNext()) {
				Card card = iter.next();
				score += card.getScore();
			}
			player.addScore(score);
			if (score != 0) {
				_board.appendMessage(Board.MessageType.RoundOver, 
					player.getName() + " received " + score + " points.");
			}
		}
	}
	
	/** 
	 * Createes an instance of game monitor.
	 * 
	 * @param board associated board.
	 */
	public GameMonitor(Board board) {
		_board = board;
	}

	/**
	 * Resets monitor to initial state.
	 */
	public void reset() {
		_curState = State.Normal;
		_stopRequested = false;
	}
	
	/**
	 * Returns current game state.
	 * 
	 * @return current game state.
	 */
	public State getCurrentState() {
		return _curState;
	}
	
	/**
	 * Returns reference to Board.
	 * 
	 * @return reference to Board.
	 */
	public Board getBoard() {
		return _board;
	}
	
	/**
	 * Verifies if specified card can be discarded at the moment.
	 * 
	 * @param card Card to check
	 * @return true if the card can be discarded.
	 */
	public boolean canDiscard(Card card) {
		
		Card lastDiscarded = _board.getDiscardPile().lastDiscarded();

		boolean ans = false;
		
		switch (_curState) {
		case Normal:
			
			if (card.getKind() == Card.Kind.Eight ||
				card.getSuit() == lastDiscarded.getSuit() ||
				card.getKind() == lastDiscarded.getKind()) {
				
				ans = true;
			} 
			
			break;
		
		case DrawTwo:
			ans = false;
			break;
			
		case LastDrawPenalty:
			ans = false;
			break;
			
		case SuitChanged:

			if (card.getKind() == Card.Kind.Eight ||
				card.getSuit() == _nextSuit ||
				card.getKind() == lastDiscarded.getKind()) {
				
				ans = true;
			}
			break;
			
		case Stacking:
			ans = true;
			break;

		case Melee:
			if (card.getSuit() == _meleeSuit &&
				card.getKind() == _meleeKind) {
					
				ans = true;
			}
			break;
			
		default:
			throw new IllegalStateException("Unknown state: " + _curState);
		}
		
		return ans;
	}

	/**
	 * Monitors game and enforces game logic until user quits or game is completed.
	 */
	public void run() {
		
		// display start message
		if (_board.getPlayer(Player.COMPUTER_PLAYER_INDEX).getScore() == 0 &&
			_board.getPlayer(Player.HUMAN_PLAYER_INDEX).getScore() == 0) {
			_board.appendMessage(Board.MessageType.Normal, "New game started.");
		} else {
			_board.appendMessage(Board.MessageType.Normal, "New round started.");
		}
		
		// notify observers to refresh
		setChanged();
		notifyObservers();
			
		while (!isGameOver() && !isRoundOver()) {
			
			// get reference to current player
			int idx = _board.getCurrentPlayerIndex();
			Player player = _board.getPlayer(idx);
			
			// obtain and process user's move 
			boolean changeTurn = false;
			Move move = player.getNextMove(this);
			changeTurn = processPlayerMove(move);

			// change turn
			if (changeTurn) {
				int curPlayerIdx = _board.getCurrentPlayerIndex();
				curPlayerIdx++;
				_board.setCurrentPlayerIndex(curPlayerIdx % Player.NUMBER_PLAYERS);
			}
			
			// restock if necessary
			if (_board.getStock().isEmpty()) {
				if (!restock()) {
					_board.appendMessage(Board.MessageType.Error,
						"Unable to restock.");
				}
			}
			
			// notify observers about change
			setChanged();
			notifyObservers();
		}
		
		// update scores (unless user had quit)
		if (!_stopRequested) {
			updateScores();
		}

		// display messages
		if (isGameOver()) {
			if (_board.getPlayer(Player.COMPUTER_PLAYER_INDEX).getScore() >= Board.LOSING_SCORE) {
				_board.appendMessage(Board.MessageType.GameOver, 
					_board.getPlayer(Player.HUMAN_PLAYER_INDEX).getName() + " Won! Game over!");
			} else if (_board.getPlayer(Player.HUMAN_PLAYER_INDEX).getScore() >= Board.LOSING_SCORE) {
				_board.appendMessage(Board.MessageType.GameOver, 
					_board.getPlayer(Player.COMPUTER_PLAYER_INDEX).getName() + " Won! Game over!");
			} else {
				_board.appendMessage(Board.MessageType.GameOver, 
					"Game over!");
			}
		} else if (isRoundOver()) {
			_board.appendMessage(Board.MessageType.Normal, 
			"Click Deal button to start next round.");
		}
		
		// show computer's hands
		_board.getPlayer(Player.COMPUTER_PLAYER_INDEX).getHand().setShowFace(true);
		
		// notify observers about change
		setChanged();
		notifyObservers();
	}
	
	/**
	 * Stops Monitor loops.
	 */
	public void stop() {
		_stopRequested = true;
	}
	
	/**
	 * Is the current round of the game over?
	 * 
	 * @return true if current round is over.
	 */
	public boolean isRoundOver() {
		return ( 
			(_board.getPlayer(Player.COMPUTER_PLAYER_INDEX).getHand().isEmpty() || 
			_board.getPlayer(Player.HUMAN_PLAYER_INDEX).getHand().isEmpty()) && 
			_curState != State.DrawTwo &&
			_curState != State.Melee );
	}
	
	/**
	 * Is game finished?
	 * 
	 * @return true if game is finished.
	 */
	public boolean isGameOver() {
		return (_stopRequested || 
			_board.getPlayer(Player.COMPUTER_PLAYER_INDEX).getScore() >= Board.LOSING_SCORE || 
			_board.getPlayer(Player.HUMAN_PLAYER_INDEX).getScore() >= Board.LOSING_SCORE);
	}
}
