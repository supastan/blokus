package data.board;

import java.util.Stack;

public class Stock {

	/** Stores cards */
	private Stack<Card> _cards;
	
	/**
	 * Creates an empty stock of cards.
	 */
	public Stock() {
		_cards = new Stack<Card>();
	}

	/** 
	 * Adds a card to the stock.
	 * 
	 * @param card card to add.
	 * @throws IllegalStateException if card is null.
	 */
	public void add(Card card) {
		if (card == null) {
			throw new IllegalStateException();
		}
		_cards.push(card);
	}

	/**
	 * Removes a single card from the top of the stock.
	 * 
	 * @return top card from the stock.
	 * @throws EmptyStackException if stock is empty.
	 */
	public Card draw() {
		return _cards.pop();
	}
	
	/**
	 * Returns number of cards in the stock.
	 * 
	 * @return number of cards in the stock.
	 */
	public int size() {
		return _cards.size();
	}
	
	/**
	 * Checks if the stock is empty.
	 * 
	 * @return true if the stock is empty.
	 */
	public boolean isEmpty() {
		return _cards.isEmpty();
	}
	
	/**
	 * Clears stock.
	 */
	public void clear() {
		_cards.clear();
	}
}
