package data.board;

import java.util.concurrent.ConcurrentLinkedQueue;

public class DiscardPile {

	/** Stores discarded cards */
	private ConcurrentLinkedQueue<Card> _pile;
	
	/** Last discarded card */
	private Card _lastDiscarded;
	
	/**
	 * Creates an empty discard pile.
	 */
	public DiscardPile() {
		_pile = new ConcurrentLinkedQueue<Card>();
	}
	
	/**
	 * Adds specified card to the pile.
	 * 
	 * @param card card to add to the pile.
	 * @throws IllegalStateException if card is null.
	 */
	public void add(Card card) {
		_pile.add(card);
		_lastDiscarded = card;
	}

	/**
	 * Removes all cards except the last one added to the pile.
	 * 
	 * @return CardCollection containing all cards except the last one added to the pile.
	 */
	public CardCollection removeAllButOne() {
		CardCollection cards = new CardCollection();
		while (size() > 1) {
			cards.add(_pile.remove());
		}
		return cards;
	}
	
	/**
	 * Returns the last discard card.
	 * 
	 * @return last discard card
	 */
	public Card lastDiscarded() {
		return _lastDiscarded;
	}
	
	/**
	 * Returns number of cards in the discard pile.
	 * 
	 * @return number of cards in the discard pile.
	 */
	public int size() {
		return _pile.size();
	}
	
	/** 
	 * Resets discarded pile state.
	 */
	public void reset() {
		_lastDiscarded = null;
		_pile.clear();
	}

	/**
	 * Checks if the pile is empty.
	 * 
	 * @return true if pile is empty.
	 */
	public boolean isEmpty() {
		return _pile.isEmpty();
	}
}
