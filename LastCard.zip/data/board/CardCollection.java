package data.board;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Random;

public class CardCollection {

	/** Stores collection of cards */
	private LinkedList<Card> _cards;
	
	/** Random number generator */
	private static Random _random;
	
	/**
	 * Creates an empty card collection.
	 */
	public CardCollection() {
		_cards = new LinkedList<Card>();
		_random = new Random();
	}
	
	/** 
	 * Adds a card to the collection
	 * 
	 * @param card card to add.
	 * @throws IllegalStateException if card is null
	 */
	public void add(Card card) {
		if (card == null) {
			throw new IllegalStateException();
		}
		_cards.add(card);
	}
	
	/** 
	 * Returns the first card in the collection.
	 * 
	 * @return the first card in the collection.
	 */
	public Card removeFirst() {
		if (isEmpty()) {
			throw new NoSuchElementException();
		}
		return _cards.remove(0);
	}
	
	/**
	 * Returns a randomly selected card from the collection.
	 * 
	 * @return randomly selected card from the collection
	 * @throws NoSuchElementException if the collection is empty
	 */
	public Card removeRandom() {
		if (isEmpty()) {
			throw new NoSuchElementException();
		}
		int idx = _random.nextInt(size());
		return _cards.remove(idx);
	}

	/**
	 * Removes the card at specified index.
	 * 
	 * @param idx index of the card to remove
	 * @return removed card
	 */
	public Card removeCard(int idx) {
		return _cards.remove(idx);
	}
	
	/**
	 * Returns the card at specified index.
	 * 
	 * @param idx index of the card to return
	 * @return card at given index
	 */
	public Card getCard(int idx) {
		return _cards.get(idx);
	}
	
	/**
	 * Returns number of cards in the collection.
	 * 
	 * @return number of cards in the collection.
	 */
	public int size() {
		return _cards.size();
	}
	
	/**
	 * Checks if the collection is empty.
	 * 
	 * @return true if the collection is empty.
	 */
	public boolean isEmpty() {
		return _cards.isEmpty();
	}
	
	/**
	 * Removes all cards in the collection.
	 */
	public void clear() {
		_cards.clear();
	}
	
	/**
	 * Returns an iterator for the cards in the collection.
	 * 
	 * @return iterator for the cards in the collection.
	 */
	public Iterator<Card> iterator() {
		return _cards.iterator();
	}
}
