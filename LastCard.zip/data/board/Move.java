package data.board;

public class Move {

	/** Move type enumeration */
	public enum Type {
		Draw,
		Discard,
		Quit,
	}
	
	/** Move type */
	private Type _type;
	
	/** Index of card to discard, or number of cards to draw */
	private int _number;
	
	/** Next suit */
	private Card.Suit _suit;
	
	/** Is LastCard is declared */
	private boolean _lastCard;
	
	/** 
	 * Creates a Move of specified type.
	 * 
	 * @param type Move Type
	 */
	public Move(Type type) {
		_type = type;
	}
	
	/**
	 * Creates a Move of specified type with given number parameter.
	 * The number may be interpreted as number of cards or index of
	 * selected card.
	 * 
	 * @param type Move Type
	 * @param number number of cards or index of selected card.
	 */
	public Move(Type type, int number) {
		_type = type;
		_number = number;
	}
	
	/**
	 * Creates a Move of specified type with given number parameter
	 * and a Suit. The number may be interpreted as number of cards or index of
	 * selected card.
	 * 
	 * @param type Move Type
	 * @param number number of cards or index of selected card.
	 * @param suit Next Suit.
	 */
	public Move(Type type, int number, Card.Suit suit) {
		_type = type;
		_number = number;
		_suit = suit;
	}
	
	/**
	 * Returns the Type of this Move.
	 * 
	 * @return Type of this Move.
	 */
	public Type getType() {
		return _type;
	}
	
	/**
	 * Returns Suit associated with current Move.
	 * 
	 * @return Suit associated with current Move.
	 */
	public Card.Suit getSuit() {
		return _suit;
	}
	
	/**
	 * Returns number associated with this Move.
	 * The number may be interpreted as number of cards or index of
	 * selected card.
	 * 
	 * @return number associated with this Move.
	 */
	public int getNumber() {
		return _number;
	}
	
	/**
	 * Sets LastCard declaration value.
	 * 
	 * @param lastCard LastCard declaration value.
	 */
	public void setLastCard(boolean lastCard) {
		_lastCard = lastCard;
	}
	
	/**
	 * Checks if LastCard has been declared.
	 * 
	 * @return true if LastCard has been declared.
	 */
	public boolean isLastCard() {
		return _lastCard;
	}
}
