package data.board;

import javax.swing.ImageIcon;

public class Card {
	
	/** Back image card name */
	private static final String BACK_IMAGE = "back.jpg";
	
	/** Suit enumeration */
	public enum Suit {
		Club,
		Diamond,
		Heart,
		Spade,
		NONE,
	}
	
	/** Kind enumeration */
	public enum Kind {
		Ace,
		Two,
		Three,
		Four,
		Five,
		Six,
		Seven,
		Eight,
		Nine,
		Ten,
		Jack,
		Queen,
		King,
	}
	
	/** Stores back image */
	private static ImageIcon _backImage;
	static {
		// load back image
		_backImage = new ImageIcon(BACK_IMAGE);
	}
	
	/** Suit for card */
	private Suit _suit;
	
	/** Kind for card */
	private Kind _kind;
	
	/** Image for card */
	private ImageIcon _image;
	
	/**
	 * Creates a card with given suit, kind and image.
	 * 
	 * @param suit suit
	 * @param kind kind
	 * @param image card image
	 */
	public Card(Suit suit, Kind kind, ImageIcon image) {
		_suit = suit;
		_kind = kind;
		_image = image;
	}
	
	/**
	 * Returns the suit of the card.
	 * 
	 * @return suit of the card.
	 */
	public Suit getSuit() {
		return _suit;
	}
	
	/**
	 * Returns the kind of the card.
	 * 
	 * @return kind of the card.
	 */
	public Kind getKind() {
		return _kind;
	}
	
	/**
	 * Returns the next higher kind.
	 * 
	 * @return the next higher kind.
	 */
	public Kind getNextKind() {
		
		switch(_kind) {
		case Ace:
			return Kind.Two;
		case Two:
			return Kind.Three;
		case Three:
			return Kind.Four;
		case Four:
			return Kind.Five;
		case Five:
			return Kind.Six;
		case Six:
			return Kind.Seven;
		case Seven:
			return Kind.Eight;
		case Eight:
			return Kind.Nine;
		case Nine:
			return Kind.Ten;
		case Ten:
			return Kind.Jack;
		case Jack:
			return Kind.Queen;
		case Queen:
			return Kind.King;
		case King:
			return Kind.Ace;

		default:
			throw new IllegalStateException("Can't return value for " + _kind);
		}
	}
	
	/**
	 * Returns numeric value associated with Kind.
	 * 
	 * @return numeric value associated with Kind.
	 */
	public int getValue() {
		
		switch(_kind) {
		case Ace:
			return 1;
		case Two:
			return 2;
		case Three:
			return 3;
		case Four:
			return 4;
		case Five:
			return 5;
		case Six:
			return 6;
		case Seven:
			return 7;
		case Eight:
			return 8;
		case Nine:
			return 9;
		case Ten:
			return 10;
		case Jack:
			return 11;
		case Queen:
			return 12;
		case King:
			return 13;

		default:
			throw new IllegalStateException("Can't return value for " + _kind);
		}
	}

	/**
	 * Returns the score corresponding to current card.
	 * 
	 * @return the score corresponding to current card.
	 */
	public int getScore() {
		
		switch(_kind) {
		case Ace:
			return 15;
		case Two:
			return 5;
		case Three:
			return 5;
		case Four:
			return 5;
		case Five:
			return 5;
		case Six:
			return 5;
		case Seven:
			return 5;
		case Eight:
			return 25;
		case Nine:
			return 5;
		case Ten:
			return 10;
		case Jack:
			return 10;
		case Queen:
			return 10;
		case King:
			return 10;

		default:
			throw new IllegalStateException("Can't return value for " + _kind);
		}
	}
	
	/**
	 * Returns the image icon of the card.
	 * 
	 * @return the image icon of the card.
	 */
	public ImageIcon getImageIcon() {
		return _image;
	}
	
	/**
	 * Returns String representation of a Card.
	 */
	@Override
	public String toString() {
		return _kind + " of " + _suit;
	}
	
	/**
	 * Returns the back image.
	 * 
	 * @return the back image.
	 */
	public static ImageIcon getBackImageIcon() {
		return _backImage;
	}
}
