package data.board;

import gui.LastCardUI;

import java.awt.Color;

import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyledDocument;
import javax.swing.text.StyleConstants.ColorConstants;
import javax.swing.text.StyleConstants.FontConstants;

import data.player.ComputerPlayer;
import data.player.HumanPlayer;
import data.player.Player;

public class Board {

	/** Number of cards dealt to players at the start of the game */
	public static final int INITIAL_CARDS_PER_PLAYER = 4;
	
	/** First player to accumulate this score loses */
	public static final int LOSING_SCORE = 250;
	
	/** Message type enumeration */
	public enum MessageType {
		Normal,
		Error,
		SpecialCard,
		LastCard,
		RoundOver,
		GameOver,
	}
	
	/** Game level enumeration */
	public enum GameLevel {
		Easy,
		Hard,
	}
	
	/** Game monitor enforces game logic */
	private GameMonitor _monitor;
	
	/** Stores players */
	private Player[] _players;
	
	/** Stores discard pile */
	private DiscardPile _discardPile;
	
	/** Stores stock */
	private Stock _stock;
	
	/** Current player index (zero-based) */
	private int _playerIdx;
	
	/** Stores game messages */
	private StyledDocument _msg;
	
	/** Game level */
	private GameLevel _level;
	
	/** 
	 * Creates an uninitialized board populated with players, stock and discard pile.
	 */
	public Board() {
		
		// create constituent objects
		_players = new Player[Player.NUMBER_PLAYERS];
		_players[Player.COMPUTER_PLAYER_INDEX] = new ComputerPlayer();
		_players[Player.HUMAN_PLAYER_INDEX] = new HumanPlayer();
		_discardPile = new DiscardPile();
		_stock = new Stock();
		_monitor = new GameMonitor(this);
		_msg = new DefaultStyledDocument();
		_level = GameLevel.Easy;
	}
	
	/**
	 * Returns reference to discarded pile.
	 * 
	 * @return reference to discarded pile.
	 */
	public DiscardPile getDiscardPile() {
		return _discardPile;
	}
	
	/**
	 * Returns reference to stock.
	 * 
	 * @return reference to stock.
	 */
	public Stock getStock() {
		return _stock;
	}
	
	/**
	 * Returns message docuemnt.
	 * 
	 * @return message docuemnt.
	 */
	public StyledDocument getMessageDoc() {
		return _msg;
	}
	
	/**
	 * Returns game level.
	 * 
	 * @return game level.
	 */
	public GameLevel getGameLevel() {
		return _level;
	}
	
	/**
	 * Sets game level to new value.
	 * 
	 * @param level new level
	 */
	public void setGameLevel(GameLevel level) {
		_level = level;
		appendMessage(MessageType.Normal, "Game level is now set to " + _level + ".");
	}
	
	/**
	 * Returns reference to monitor.
	 * 
	 * @return reference to monitor.
	 */
	public GameMonitor getGameMonitor() {
		return _monitor;
	}
	
	/**
	 * Returns player for the specifed index.
	 * 
	 * @param idx player index
	 * @return player for the specifed index.
	 */
	public Player getPlayer(int idx) {
		return _players[idx];
	}
	
	/**
	 * Returns index for current player.
	 * 
	 * @return current player index
	 */
	public int getCurrentPlayerIndex() {
		return _playerIdx;
	}
	
	/**
	 * Sets current player index to a new value.
	 * 
	 * @param idx new player index
	 */
	public void setCurrentPlayerIndex(int idx) {
		if (idx < Player.COMPUTER_PLAYER_INDEX || idx > Player.HUMAN_PLAYER_INDEX) {
			throw new IndexOutOfBoundsException("idx=" + idx);
		}
		_playerIdx = idx;
	}
	
	/**
	 * Reset Board state.
	 * 
	 * @param resetScores indicates whether scores should be reset.
	 */
	public void reset(boolean resetScores) {
		
		// reset
		_players[Player.COMPUTER_PLAYER_INDEX].reset(resetScores);
		_players[Player.HUMAN_PLAYER_INDEX].reset(resetScores);
		_monitor.reset();
		_discardPile.reset();
		_stock.clear();
		try {
			_msg.remove(0, _msg.getLength());
		} catch (BadLocationException ex) {
			// do nothing
		}
		
		// set defaults
		_playerIdx = 0;
	}
	
	/**
	 * Initializes all components that comprise the board, including players, 
	 * stock and discard pile.
	 */
	public void initialize() {
		// deal cards to players
		Deck deck = new Deck();
		for (int i = 0; i < INITIAL_CARDS_PER_PLAYER; i++) {
			_players[Player.COMPUTER_PLAYER_INDEX].deal(deck.removeRandom());
			_players[Player.HUMAN_PLAYER_INDEX].deal(deck.removeRandom());
		}
		
		// add one more card to the computer. the initial
		// card will be played by computer
		_players[Player.COMPUTER_PLAYER_INDEX].deal(deck.removeRandom());
		
		// shuffle and dump rest of the cards on stock pile
		while (!deck.isEmpty()) {
			_stock.add(deck.removeRandom());
		}
		
		// computer player plays the initial hand
		setCurrentPlayerIndex(Player.COMPUTER_PLAYER_INDEX);
		
		// start the monitor
		new Thread(_monitor).start();
	}

	/**
	 * Appends String message to the StyledDocument message document.
	 * 
	 * @param type message type
	 * @param str message
	 */
	public void appendMessage(MessageType type, String str) {
		
		MutableAttributeSet attribSet = new SimpleAttributeSet(); 
		FontConstants.setFontSize(attribSet, 14);

		// build AttributeSet appropriate for message type
		switch(type) {
		
		case Error:
			ColorConstants.setForeground(attribSet, Color.RED);
			break;
			
		case SpecialCard:
			ColorConstants.setForeground(attribSet, Color.BLUE);
			FontConstants.setBold(attribSet, true);
			FontConstants.setItalic(attribSet, true);
			break;
			
		case LastCard:
			ColorConstants.setForeground(attribSet, Color.MAGENTA);
			FontConstants.setFontSize(attribSet, 18);
			FontConstants.setBold(attribSet, true);
			break;
			
		case RoundOver:
			ColorConstants.setForeground(attribSet, LastCardUI.BACKGROUND_COLOR);
			FontConstants.setFontSize(attribSet, 18);
			FontConstants.setBold(attribSet, true);
			FontConstants.setItalic(attribSet, true);
			break;
			
		case GameOver:
			ColorConstants.setForeground(attribSet, Color.DARK_GRAY);
			FontConstants.setFontSize(attribSet, 25);
			FontConstants.setBold(attribSet, true);
			break;
		}
		
		// write message
		try {
			_msg.insertString(_msg.getLength(), str, attribSet);
			_msg.insertString(_msg.getLength(), "\n", attribSet);
		} catch (BadLocationException ex) {
			// do nothing
		}
	}
}
