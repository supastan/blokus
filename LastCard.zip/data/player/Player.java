package data.player;

import java.util.concurrent.ArrayBlockingQueue;

import data.board.Card;
import data.board.GameMonitor;
import data.board.Move;

abstract public class Player {

	/** Supported number of players */
	public static final int NUMBER_PLAYERS = 2;
	
	/** Index for computer player */
	public static final int COMPUTER_PLAYER_INDEX = 0;
	
	/** Index for human player */
	public static final int HUMAN_PLAYER_INDEX = 1;
	
	/** Player move queue size.  Just need one for thread synchronization. */
	private static final int QUEUE_SIZE = 1;
	
	/**
	 * Queue used to force GameMonitor's thread to wait for
	 * user input.
	 */
	private ArrayBlockingQueue<Move> _moveQueue;
	
	/** Stores player's hand */
	protected Hand _hand;
	
	/** Player's name */
	private String _name;
	
	/** Player's score */
	private int _score;
	
	/**
	 * Creates an instance of Player.
	 * 
	 * @param name Player's display name.
	 */
	public Player(String name) {
		_name = name;
		_moveQueue = new ArrayBlockingQueue<Move>(QUEUE_SIZE);
	}
	
	/**
	 * Returns player's hand.
	 * 
	 * @return player's hand.
	 */
	public Hand getHand() {
		return _hand;
	}
	
	/**
	 * Returns player's name.
	 * 
	 * @return player's name.
	 */
	public String getName() {
		return _name;
	}
	
	/**
	 * Returns player's score.
	 * 
	 * @return player's score.
	 */
	public int getScore() {
		return _score;
	}
	
	/**
	 * Adds score to player's total score.
	 * 
	 * @param score score to add.
	 */
	public void addScore(int score) {
		_score += score;
	}

	/**
	 * Reset player's state.
	 * 
	 * @param resetScores if the score needs reset.
	 */
	public void reset(boolean resetScores) {
		_hand.clear();
		_hand.setShowFace(showFace());
		if (resetScores) {
			_score = 0;
		}
	}
	
	/**
	 * Deals a single card to the player.
	 * 
	 * @param card Card to deal.
	 */
	public void deal(Card card) {
		_hand.add(card);
	}

	/**
	 * Removes a Move from the MoveQueue.  This method blocks the
	 * GameMonitor thread until a Move becomes available in the Queue.
	 * 
	 * @param monitor instance of GameMonitor.
	 * @return next Move
	 */
	public Move getNextMove(GameMonitor monitor) {
		Move move = null;
		try {
			move = _moveQueue.take();
		} catch (InterruptedException ex) {
			// do nothing
		}
		return move;
	}
	
	/**
	 * Places a Move to the MoveQueue.  This method is called by UI
	 * compoments to place user's input into the Queue.
	 * 
	 * @param move next Move.
	 */
	public void putNextMove(Move move) {
		try {
			_moveQueue.put(move);
		} catch (InterruptedException ex) {
			// do nothing
		}
	}
	
	/**
	 * Indicates whether hand should be shown face up in general.
	 * 
	 * @return true if hand should be shown face up.
	 */
	abstract public boolean showFace();
}
