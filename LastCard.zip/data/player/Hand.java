package data.player;

import data.board.CardCollection;

public class Hand extends CardCollection {

	/** Index of the selected card */
	private int _selectedIdx;
	
	/** Should player's hand be shown face up? */
	private boolean _showFace;
	
	/** Indicates whether selection should be bordered when displayed */
	private boolean _borderSelected;
	
	/**
	 * Creates an instance of a Hand.
	 * 
	 * @param showFace whether face should be shown when displayed.
	 */
	public Hand(boolean showFace) {
		_showFace = showFace;
		
		// selection should be bordered by default.
		_borderSelected = true;
	}
	
	/**
	 * Selects a card at specified index.
	 * 
	 * @param idx selected Card's index.
	 */
	public void setSelectedCardIndex(int idx) {
		_selectedIdx = idx;
	}
	
	/**
	 * Returns the index of the selected Card.
	 * 
	 * @return the index of the selected Card.
	 */
	public int getSelectedCardIndex() {
		return _selectedIdx;
	}
	
	/**
	 * Checks whether face should be shown when displayed.
	 * 
	 * @return true if face should be shown when displayed.
	 */
	public boolean isShowFace() {
		return _showFace;
	}
	
	/**
	 * Indicates whether face should be shown when displayed.
	 * 
	 * @param showFace whether face should be shown when displayed.
	 */
	public void setShowFace(boolean showFace) {
		_showFace = showFace;
	}

	/**
	 * Checks whether selection should be bordered.
	 * 
	 * @return true if selection should be bordered.
	 */
	public boolean isBorderSelected() {
		return _borderSelected;
	}
	
	/**
	 * Indicates whether selection should be bordered.
	 *  
	 * @param borderSelected whether selection should be bordered.
	 */
	public void setBorderSelected(boolean borderSelected) {
		_borderSelected = borderSelected;
	}
}
