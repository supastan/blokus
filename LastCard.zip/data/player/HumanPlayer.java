package data.player;


public class HumanPlayer extends Player {
	
	/** Name of the Human player */
	private static final String NAME = "User";
	
	/**
	 * Creates an instance of Human player.
	 */
	public HumanPlayer() {
		super(NAME);
		
		// hands should be displayed face up by default.
		_hand = new Hand(true);
	}

	/**
	 * Indicates whether hand should be shown face up in general.
	 */
	@Override
	public boolean showFace() {
		return true;
	}
}
