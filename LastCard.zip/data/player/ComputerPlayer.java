package data.player;

import java.util.Iterator;


import data.board.Card;
import data.board.GameMonitor;
import data.board.Move;

public class ComputerPlayer extends Player {

	/** Name of the player */
	private static final String NAME = "Computer";
	
	/** 
	 * Creates an instance of Computer player.
	 */
	public ComputerPlayer() {
		super(NAME);
		
		// hands should be displayed face down (unless game is over)
		_hand = new Hand(false);
		
		// no border to be shown on selected cards (when game is over)
		_hand.setBorderSelected(false);
	}
	
	@Override
	public Move getNextMove(GameMonitor monitor) {
		Move move = null;
		
		int idx = 0;
		boolean discard = false;
		// if starting first move, discard the first card
		if (monitor.getBoard().getDiscardPile().isEmpty()) {
			discard = true;
		} else {

			// see if there are any cards we can discard
			Iterator<Card> iter = _hand.iterator();
			while (!discard && iter.hasNext()) {
				Card cur = iter.next();
				if (monitor.canDiscard(cur)) {
					discard = true;
				} else {
					idx ++;
				}
			}
		}
		
		if (discard) {
			Card card = _hand.getCard(idx);

			// set next suit to some default
			Card.Suit next = Card.Suit.Diamond;
			
			// if Eight is selected, determine next suit
			if (card.getKind() == Card.Kind.Eight) {
				
				// select Suit from one of remaining cards
				boolean suitFound = false;
				for (int i = 0; !suitFound && i < _hand.size(); i++) {
					
					// if matches discarding card, skip
					if (i == idx) {
						continue;
					}
					next = _hand.getCard(i).getSuit();
					suitFound = true;
				}
			}
			move = new Move(Move.Type.Discard, idx, next);
			if (_hand.size() == 2) {
				move.setLastCard(true);
			}
		} else {
			
			int numCards = 1;
			switch(monitor.getCurrentState()) {
			case DrawTwo:
				numCards = 2;
				break;
			case Melee:
				Card lastDiscarded = monitor.getBoard().getDiscardPile().lastDiscarded();
				numCards = lastDiscarded.getValue();
			}
			move = new Move(Move.Type.Draw, numCards);
		}
		
		return move;
	}

	/**
	 * Indicates whether hand should be shown face up in general.
	 */
	@Override
	public boolean showFace() {
		return false;
	}
}
